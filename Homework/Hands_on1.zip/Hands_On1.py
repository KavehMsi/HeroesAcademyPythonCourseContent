#!/usr/bin/env python
# coding: utf-8

# Hands-on Test #1 - Basic Data Structures in Python

# 1- Write an arithmetic expression including the operators "+", "-", "*", "/", "%" and "***" which equals to 673

# In[14]:


# Type your code here...


# 2- How would you find the square root of a number(float or integer) and the root of a number?

# In[15]:


# Square root(type your code below): 

# Root(type your code below):


# 3- Using slicing method, print the letter "s" with two indexing method.

# In[16]:


my_string = "Python course!"
#Type method 1 here


# In[17]:


#Type method 2 here


# 4- Using slicing method, print the word "course" in the string below.

# In[18]:


my_string = "Python course!"

#Type your code here


# 5- Using slicing method, print the word "course" in reverse

# In[19]:


my_string = "Python course!"

#Type your code here


# 6- Print the sentence "Welcome Welcome to this course" using the strings below and the operators "+" and "*" and also add your full name at the end the string.

# In[28]:


word1 = "Welcome "
word2 = "to"
word3 = "this"
word4 = "course"

#Type your code here


# 7- Sort the list below.

# In[30]:


my_list = [67,1,2,-1,-5,0,1.4,1.2,66,78,-1.72]

#Type your code here


# 8- Reassign 'first name' and 'last name' in the nested list below with your name.

# In[34]:


my_list2 = [["Clint", "Eastwood"] , 
            ["first name", "last name"] , 
            ["Jack", "Black"], 
            ["Jason", "Statham"],
            ["Emma", "Watson"]
           ]

#Type your code here


# 9- Insert the element "Banana" as the third element in the list below 

# In[35]:


my_list3 = ["Fruits" , "Cucumber" , "Apple" , "Watermelon" , "Pineapple"]

#Type your code here


# 10. How can we merge two lists (Add one list to the end of the other)?

# In[37]:



#Type your example here

