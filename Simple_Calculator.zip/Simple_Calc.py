#!/usr/bin/env python
# coding: utf-8

# In[ ]:


def getting_input():
    expression = input()
    expression = expression.replace(" ","")
    if expression[0] == '+':
        expression = expression[1::]
    return expression

def calculate_every_multiplication(element):
    mult = element.split("*")
    result = 1
    
    for i in mult:
        result = result * int(i)
    return result
    
def calculate_every_element(sums): 
    
    for i in range(0 , len(sums) , 1):
        if '*' in sums[i]:
            sums[i] = calculate_every_multiplication(sums[i])
        else:
            sums[i] = int(sums[i])
    
def process(expr):
    sums = expr.split("+")
    calculate_every_element(sums)
    return sums
    

def output(final_sums):
    result = 0
    
    for i in final_sums:
        result = result + i
    
    print(result)
    
    
expression = getting_input()

final_sums = process(expression)

output(final_sums)


# In[ ]:




